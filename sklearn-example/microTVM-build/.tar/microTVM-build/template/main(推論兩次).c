#include <stdio.h>
#include <tvmgen_default.h>

// 定義工作空間
uint8_t workspace[TVMGEN_DEFAULT_WORKSPACE_SIZE];

int main() {
    // 第一筆資料
    float input_data_1[4] = {6.3, 3.3, 6.0, 2.5};
    int32_t output0_data_1;
    float output1_data_1[3];

    struct tvmgen_default_inputs inputs_1 = {
        .float_input = (void*)input_data_1
    };

    struct tvmgen_default_outputs outputs_1 = {
        .output0 = (void*)&output0_data_1,
        .output1 = (void*)output1_data_1
    };

    int32_t result_1 = tvmgen_default_run(&inputs_1, &outputs_1);
    if (result_1 != 0) {
        fprintf(stderr, "Error: tvmgen_default_run failed with code %d\n", result_1);
        return -1;
    }

    printf("First Inference:\n");
    printf("Output0: %d\n", output0_data_1);
    printf("Output1: %f %f %f\n", output1_data_1[0], output1_data_1[1], output1_data_1[2]);

    // 第二筆資料
    float input_data_2[4] = {5.1, 3.5, 1.4, 0.2};
    int32_t output0_data_2;
    float output1_data_2[3];

    struct tvmgen_default_inputs inputs_2 = {
        .float_input = (void*)input_data_2
    };

    struct tvmgen_default_outputs outputs_2 = {
        .output0 = (void*)&output0_data_2,
        .output1 = (void*)output1_data_2
    };

    int32_t result_2 = tvmgen_default_run(&inputs_2, &outputs_2);
    if (result_2 != 0) {
        fprintf(stderr, "Error: tvmgen_default_run failed with code %d\n", result_2);
        return -1;
    }

    printf("Second Inference:\n");
    printf("Output0: %d\n", output0_data_2);
    printf("Output1: %f %f %f\n", output1_data_2[0], output1_data_2[1], output1_data_2[2]);

    return 0;
}
