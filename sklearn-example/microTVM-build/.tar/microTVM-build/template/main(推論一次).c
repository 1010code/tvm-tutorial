#include <stdio.h>
#include <tvmgen_default.h>

// 定義工作空間
uint8_t workspace[TVMGEN_DEFAULT_WORKSPACE_SIZE];

int main() {
    // 準備輸入及輸出資料
    float input_data[4] = {6.3, 3.3, 6.0, 2.5};
    int32_t output0_data;
    float output1_data[3];

    struct tvmgen_default_inputs inputs = {
        .float_input = (void*)input_data
    };

    struct tvmgen_default_outputs outputs = {
        .output0 = (void*)&output0_data,
        .output1 = (void*)output1_data
    };

    // 呼叫 run 函式，將 inputs & outputs 當作參數傳入
    int32_t result = tvmgen_default_run(&inputs, &outputs);
    if (result != 0) {
        fprintf(stderr, "Error: tvmgen_default_run failed with code %d\n", result);
        return -1;
    }

    printf("First Inference:\n");
    printf("Output0: %d\n", output0_data);
    printf("Output1: %f %f %f\n", output1_data[0], output1_data[1], output1_data[2]);

    return 0;
}
