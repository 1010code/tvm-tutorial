// tvm target: c -keys=cpu 
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add(float* p0, float* T_add, uint8_t* global_const_workspace_12_var, uint8_t* global_workspace_13_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_1(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_20_var, uint8_t* global_workspace_21_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_argmax(float* p0, int32_t* p0_red, uint8_t* global_const_workspace_14_var, uint8_t* global_workspace_15_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast(float* p0, double* T_cast, uint8_t* global_const_workspace_2_var, uint8_t* global_workspace_3_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_1(double* p0, float* T_cast, uint8_t* global_const_workspace_8_var, uint8_t* global_workspace_9_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_2(int32_t* p0, int64_t* T_cast, uint8_t* global_const_workspace_16_var, uint8_t* global_workspace_17_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_divide(float* p0, float* p1, float* T_divide, uint8_t* global_const_workspace_34_var, uint8_t* global_workspace_35_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_18_var, uint8_t* global_workspace_19_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply(double* p0, double* T_multiply, uint8_t* global_const_workspace_6_var, uint8_t* global_workspace_7_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply_1(float* p0, float* T_multiply, uint8_t* global_const_workspace_28_var, uint8_t* global_workspace_29_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_dense(float* p0, float* compute, uint8_t* global_const_workspace_10_var, uint8_t* global_workspace_11_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_softmax(float* p0, float* T_softmax_norm, uint8_t* global_const_workspace_26_var, uint8_t* global_workspace_27_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_sqrt(float* p0, float* T_sqrt, uint8_t* global_const_workspace_30_var, uint8_t* global_workspace_31_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract(double* p0, double* T_subtract, uint8_t* global_const_workspace_4_var, uint8_t* global_workspace_5_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_sum(float* p0, float* p0_red, uint8_t* global_const_workspace_32_var, uint8_t* global_workspace_33_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take(int64_t* p0, int32_t* T_take, uint8_t* global_const_workspace_24_var, uint8_t* global_workspace_25_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_22_var, uint8_t* global_workspace_23_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(float* float_input_buffer_var, int64_t* output_buffer_var, float* output2_buffer_var, uint8_t* global_const_workspace_0_var, uint8_t* global_workspace_1_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float expf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float sqrtf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add(float* p0, float* T_add, uint8_t* global_const_workspace_12_var, uint8_t* global_workspace_13_var) {
  void* fused_constant_3_let = (&(global_const_workspace_12_var[128]));
  for (int32_t ax1_inner = 0; ax1_inner < 3; ++ax1_inner) {
    T_add[ax1_inner] = (p0[ax1_inner] + ((float*)fused_constant_3_let)[ax1_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_1(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_20_var, uint8_t* global_workspace_21_var) {
  T_add[0] = (p0[0] + (int64_t)3);
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_argmax(float* p0, int32_t* p0_red, uint8_t* global_const_workspace_14_var, uint8_t* global_workspace_15_var) {
  void* p0_red_temp_v0_let = (&(global_workspace_15_var[48]));
  void* p0_red_temp_v1_let = (&(global_workspace_15_var[64]));
  ((int32_t*)p0_red_temp_v0_let)[0] = -1;
  ((float*)p0_red_temp_v1_let)[0] = -3.402823e+38f;
  for (int32_t k1 = 0; k1 < 3; ++k1) {
    int32_t condval;
    if (((p0[k1] < ((float*)p0_red_temp_v1_let)[0]) || ((((float*)p0_red_temp_v1_let)[0] == p0[k1]) && (((int32_t*)p0_red_temp_v0_let)[0] < k1)))) {
      condval = ((int32_t*)p0_red_temp_v0_let)[0];
    } else {
      condval = k1;
    }
    ((int32_t*)p0_red_temp_v0_let)[0] = condval;
    float condval_1;
    if ((p0[k1] < ((float*)p0_red_temp_v1_let)[0])) {
      condval_1 = ((float*)p0_red_temp_v1_let)[0];
    } else {
      condval_1 = p0[k1];
    }
    ((float*)p0_red_temp_v1_let)[0] = condval_1;
  }
  p0_red[0] = ((int32_t*)p0_red_temp_v0_let)[0];
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast(float* p0, double* T_cast, uint8_t* global_const_workspace_2_var, uint8_t* global_workspace_3_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 4; ++ax1_inner) {
    T_cast[ax1_inner] = ((double)p0[ax1_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_1(double* p0, float* T_cast, uint8_t* global_const_workspace_8_var, uint8_t* global_workspace_9_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 4; ++ax1_inner) {
    T_cast[ax1_inner] = ((float)p0[ax1_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_2(int32_t* p0, int64_t* T_cast, uint8_t* global_const_workspace_16_var, uint8_t* global_workspace_17_var) {
  T_cast[0] = ((int64_t)p0[0]);
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_divide(float* p0, float* p1, float* T_divide, uint8_t* global_const_workspace_34_var, uint8_t* global_workspace_35_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 3; ++ax1_inner) {
    T_divide[ax1_inner] = (p0[ax1_inner] / p1[0]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_18_var, uint8_t* global_workspace_19_var) {
  T_less[0] = ((int8_t)(p0[0] < (int64_t)0));
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply(double* p0, double* T_multiply, uint8_t* global_const_workspace_6_var, uint8_t* global_workspace_7_var) {
  void* fused_constant_1_let = (&(global_const_workspace_6_var[48]));
  for (int32_t ax1_inner = 0; ax1_inner < 4; ++ax1_inner) {
    T_multiply[ax1_inner] = (p0[ax1_inner] * ((double*)fused_constant_1_let)[ax1_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply_1(float* p0, float* T_multiply, uint8_t* global_const_workspace_28_var, uint8_t* global_workspace_29_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 3; ++ax1_inner) {
    T_multiply[ax1_inner] = (p0[ax1_inner] * p0[ax1_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_dense(float* p0, float* compute, uint8_t* global_const_workspace_10_var, uint8_t* global_workspace_11_var) {
  void* fused_constant_2_let = (&(global_const_workspace_10_var[0]));
  void* packed_weight_let = (&(global_workspace_11_var[0]));
  void* compute_global_let = (&(global_workspace_11_var[64]));
  for (int32_t y = 0; y < 4; ++y) {
    for (int32_t x = 0; x < 3; ++x) {
      ((float*)packed_weight_let)[((y * 3) + x)] = ((float*)fused_constant_2_let)[((x * 4) + y)];
    }
  }
  for (int32_t x_c_init = 0; x_c_init < 3; ++x_c_init) {
    ((float*)compute_global_let)[x_c_init] = 0.000000e+00f;
  }
  for (int32_t k_outer = 0; k_outer < 4; ++k_outer) {
    for (int32_t x_c = 0; x_c < 3; ++x_c) {
      ((float*)compute_global_let)[x_c] = (((float*)compute_global_let)[x_c] + (p0[k_outer] * ((float*)packed_weight_let)[((k_outer * 3) + x_c)]));
    }
  }
  for (int32_t x_inner_inner = 0; x_inner_inner < 3; ++x_inner_inner) {
    compute[x_inner_inner] = ((float*)compute_global_let)[x_inner_inner];
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_softmax(float* p0, float* T_softmax_norm, uint8_t* global_const_workspace_26_var, uint8_t* global_workspace_27_var) {
  void* T_softmax_maxelem_let = (&(global_workspace_27_var[32]));
  void* T_softmax_exp_let = (&(global_workspace_27_var[16]));
  void* T_softmax_expsum_let = (&(global_workspace_27_var[32]));
  ((float*)T_softmax_maxelem_let)[0] = -3.402823e+38f;
  for (int32_t k = 0; k < 3; ++k) {
    float v_ = ((float*)T_softmax_maxelem_let)[0];
    float v__1 = p0[k];
    ((float*)T_softmax_maxelem_let)[0] = ((v_) > (v__1) ? (v_) : (v__1));
  }
  for (int32_t i1 = 0; i1 < 3; ++i1) {
    ((float*)T_softmax_exp_let)[i1] = expf((p0[i1] - ((float*)T_softmax_maxelem_let)[0]));
  }
  ((float*)T_softmax_expsum_let)[0] = 0.000000e+00f;
  for (int32_t k_1 = 0; k_1 < 3; ++k_1) {
    ((float*)T_softmax_expsum_let)[0] = (((float*)T_softmax_expsum_let)[0] + ((float*)T_softmax_exp_let)[k_1]);
  }
  for (int32_t i1_1 = 0; i1_1 < 3; ++i1_1) {
    T_softmax_norm[i1_1] = (((float*)T_softmax_exp_let)[i1_1] / ((float*)T_softmax_expsum_let)[0]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_sqrt(float* p0, float* T_sqrt, uint8_t* global_const_workspace_30_var, uint8_t* global_workspace_31_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 3; ++ax1_inner) {
    T_sqrt[ax1_inner] = sqrtf(p0[ax1_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_subtract(double* p0, double* T_subtract, uint8_t* global_const_workspace_4_var, uint8_t* global_workspace_5_var) {
  void* fused_constant_let = (&(global_const_workspace_4_var[80]));
  for (int32_t ax1_inner = 0; ax1_inner < 4; ++ax1_inner) {
    T_subtract[ax1_inner] = (p0[ax1_inner] - ((double*)fused_constant_let)[ax1_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_sum(float* p0, float* p0_red, uint8_t* global_const_workspace_32_var, uint8_t* global_workspace_33_var) {
  p0_red[0] = 0.000000e+00f;
  for (int32_t k1 = 0; k1 < 3; ++k1) {
    p0_red[0] = (p0_red[0] + p0[k1]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take(int64_t* p0, int32_t* T_take, uint8_t* global_const_workspace_24_var, uint8_t* global_workspace_25_var) {
  void* fused_constant_4_let = (&(global_const_workspace_24_var[112]));
  int64_t v_ = (int64_t)0;
  int64_t v__1 = p0[0];
  int64_t v__2 = (v_) > (v__1) ? (v_) : (v__1);
  int64_t v__3 = (int64_t)2;
  T_take[0] = ((int32_t*)fused_constant_4_let)[((v__2) < (v__3) ? (v__2) : (v__3))];
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_22_var, uint8_t* global_workspace_23_var) {
  int64_t condval;
  if ((0 < ((int32_t)((bool)p0[0])))) {
    condval = p1[0];
  } else {
    condval = p2[0];
  }
  T_where[0] = condval;
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(float* float_input_buffer_var, int64_t* output_buffer_var, float* output2_buffer_var, uint8_t* global_const_workspace_0_var, uint8_t* global_workspace_1_var) {
  void* sid_10_let = (&(global_workspace_1_var[48]));
  void* sid_14_let = (&(global_workspace_1_var[0]));
  void* sid_5_let = (&(global_workspace_1_var[80]));
  void* sid_9_let = (&(global_workspace_1_var[64]));
  void* sid_8_let = (&(global_workspace_1_var[16]));
  void* sid_2_let = (&(global_workspace_1_var[32]));
  void* sid_3_let = (&(global_workspace_1_var[0]));
  void* sid_11_let = (&(global_workspace_1_var[32]));
  void* sid_6_let = (&(global_workspace_1_var[0]));
  void* sid_12_let = (&(global_workspace_1_var[48]));
  void* sid_7_let = (&(global_workspace_1_var[32]));
  void* sid_1_let = (&(global_workspace_1_var[64]));
  void* sid_4_let = (&(global_workspace_1_var[48]));
  void* sid_15_let = (&(global_workspace_1_var[32]));
  void* sid_16_let = (&(global_workspace_1_var[16]));
  void* sid_17_let = (&(global_workspace_1_var[32]));
  if (tvmgen_default_fused_cast(float_input_buffer_var, sid_1_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_subtract(sid_1_let, sid_2_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_multiply(sid_2_let, sid_3_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_cast_1(sid_3_let, sid_4_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_dense(sid_4_let, sid_5_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add(sid_5_let, sid_6_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_argmax(sid_6_let, sid_7_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_cast_2(sid_7_let, sid_8_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less(sid_8_let, sid_9_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_1(sid_8_let, sid_10_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where(sid_9_let, sid_10_let, sid_8_let, sid_11_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take(sid_11_let, sid_12_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_cast_2(sid_12_let, output_buffer_var, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_softmax(sid_6_let, sid_14_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_multiply_1(sid_14_let, sid_15_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_sqrt(sid_15_let, sid_16_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_sum(sid_16_let, sid_17_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_divide(sid_14_let, sid_17_let, output2_buffer_var, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  return 0;
}

