#include "tvm/runtime/c_runtime_api.h"
#ifdef __cplusplus
extern "C" {
#endif
__attribute__((section(".rodata.tvm"), ))
static const struct global_const_workspace {
  float fused_constant_2_let[12] __attribute__((aligned(16))); // 48 bytes, aligned offset: 0
  double fused_constant_1_let[4] __attribute__((packed, aligned(16))); // 32 bytes, aligned offset: 48
  double fused_constant_let[4] __attribute__((packed, aligned(16))); // 32 bytes, aligned offset: 80
  int32_t fused_constant_4_let[3] __attribute__((packed, aligned(16))); // 12 bytes, aligned offset: 112
  float fused_constant_3_let[3] __attribute__((packed, aligned(16))); // 12 bytes, aligned offset: 128
} global_const_workspace = {
  .fused_constant_2_let = {
    -0x1.ecb176p-1, 0x1.06ef8ap+0, -0x1.bde4fcp+0, -0x1.98f52cp+0, 0x1.f0c30ep-2, -0x1.5f80a6p-2, -0x1.33b818p-2, -0x1.5663eep-1, 
    0x1.e89fdep-2, -0x1.5e1ecp-1, 0x1.056982p+1, 0x1.221392p+1
  },
  .fused_constant_1_let = {
    0x1.34af2ap+0, 0x1.330546p+1, 0x1.2adde2p-1, 0x1.5a54fap+0
  },
  .fused_constant_let = {
    0x1.75f16p+2, 0x1.813814p+1, 0x1.ef6bc4p+1, 0x1.3d323ap+0
  },
  .fused_constant_4_let = {
    +0x00000000, +0x00000001, +0x00000002
  },
  .fused_constant_3_let = {
    -0x1.333692p-1, 0x1.d6548ap+0, -0x1.3cb94p+0
  },
};// of total size 140 bytes
__attribute__((section(".bss.noinit.tvm"), aligned(16)))
static uint8_t global_workspace[96];
#include <tvmgen_default.h>
TVM_DLL int32_t tvmgen_default___tvm_main__(void* float_input,void* output0,void* output1,uint8_t* global_const_workspace_0_var,uint8_t* global_workspace_1_var);
int32_t tvmgen_default_run(struct tvmgen_default_inputs* inputs,struct tvmgen_default_outputs* outputs) {return tvmgen_default___tvm_main__(inputs->float_input,outputs->output0,outputs->output1,((uint8_t*)&global_const_workspace),((uint8_t*)&global_workspace));
}
#ifdef __cplusplus
}
#endif
;