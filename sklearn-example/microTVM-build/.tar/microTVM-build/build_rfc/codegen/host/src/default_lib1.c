// tvm target: c -keys=cpu 
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_8_var, uint8_t* global_workspace_9_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_1(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_12_var, uint8_t* global_workspace_13_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_10(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_86_var, uint8_t* global_workspace_87_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_2(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_20_var, uint8_t* global_workspace_21_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_3(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_28_var, uint8_t* global_workspace_29_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_4(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_38_var, uint8_t* global_workspace_39_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_5(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_46_var, uint8_t* global_workspace_47_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_6(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_56_var, uint8_t* global_workspace_57_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_7(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_66_var, uint8_t* global_workspace_67_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_8(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_74_var, uint8_t* global_workspace_75_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_9(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_82_var, uint8_t* global_workspace_83_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_argmax(float* p0, int32_t* p0_red, uint8_t* global_const_workspace_94_var, uint8_t* global_workspace_95_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast(int32_t* p0, int64_t* T_cast, uint8_t* global_const_workspace_96_var, uint8_t* global_workspace_97_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_gather(float* p0, float* T_gather, uint8_t* global_const_workspace_2_var, uint8_t* global_workspace_3_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_gather_1(float* p0, int64_t* p1, float* T_gather, uint8_t* global_const_workspace_24_var, uint8_t* global_workspace_25_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_10_var, uint8_t* global_workspace_11_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_1(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_18_var, uint8_t* global_workspace_19_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_2(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_26_var, uint8_t* global_workspace_27_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_3(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_36_var, uint8_t* global_workspace_37_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_4(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_44_var, uint8_t* global_workspace_45_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_5(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_54_var, uint8_t* global_workspace_55_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_6(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_64_var, uint8_t* global_workspace_65_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_7(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_72_var, uint8_t* global_workspace_73_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_8(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_84_var, uint8_t* global_workspace_85_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_equal(float* p0, int8_t* T_less_equal, uint8_t* global_const_workspace_4_var, uint8_t* global_workspace_5_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_equal_1(float* p0, float* p1, int8_t* T_less_equal, uint8_t* global_const_workspace_34_var, uint8_t* global_workspace_35_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_equal_2(float* p0, float* p1, int8_t* T_less_equal, uint8_t* global_const_workspace_62_var, uint8_t* global_workspace_63_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_sum(float* p0, float* p0_red, uint8_t* global_const_workspace_92_var, uint8_t* global_workspace_93_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take(int64_t* p0, int64_t* T_take, uint8_t* global_const_workspace_16_var, uint8_t* global_workspace_17_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_1(int64_t* p0, float* T_take, uint8_t* global_const_workspace_32_var, uint8_t* global_workspace_33_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_2(int64_t* p0, int64_t* T_take, uint8_t* global_const_workspace_42_var, uint8_t* global_workspace_43_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_3(int64_t* p0, int64_t* T_take, uint8_t* global_const_workspace_50_var, uint8_t* global_workspace_51_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_4(int64_t* p0, float* T_take, uint8_t* global_const_workspace_60_var, uint8_t* global_workspace_61_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_5(int64_t* p0, int64_t* T_take, uint8_t* global_const_workspace_70_var, uint8_t* global_workspace_71_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_6(int64_t* p0, int64_t* T_take, uint8_t* global_const_workspace_78_var, uint8_t* global_workspace_79_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_7(int64_t* p0, float* T_take, uint8_t* global_const_workspace_90_var, uint8_t* global_workspace_91_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where(int8_t* p0, int64_t* T_where, uint8_t* global_const_workspace_6_var, uint8_t* global_workspace_7_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_1(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_14_var, uint8_t* global_workspace_15_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_10(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_80_var, uint8_t* global_workspace_81_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_11(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_88_var, uint8_t* global_workspace_89_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_2(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_22_var, uint8_t* global_workspace_23_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_3(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_30_var, uint8_t* global_workspace_31_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_4(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_40_var, uint8_t* global_workspace_41_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_5(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_48_var, uint8_t* global_workspace_49_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_6(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_52_var, uint8_t* global_workspace_53_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_7(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_58_var, uint8_t* global_workspace_59_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_8(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_68_var, uint8_t* global_workspace_69_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_9(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_76_var, uint8_t* global_workspace_77_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(float* float_input_buffer_var, int64_t* output_buffer_var, float* output2_buffer_var, uint8_t* global_const_workspace_0_var, uint8_t* global_workspace_1_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_8_var, uint8_t* global_workspace_9_var) {
  void* fused_constant_4_let = (&(global_const_workspace_8_var[18624]));
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    T_add[ax1_inner] = (p0[ax1_inner] + ((int64_t*)fused_constant_4_let)[ax1_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_1(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_12_var, uint8_t* global_workspace_13_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_add[ax0_inner] = (p0[ax0_inner] + (int64_t)310);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_10(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_86_var, uint8_t* global_workspace_87_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_add[ax0_inner] = (p0[ax0_inner] + (int64_t)310);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_2(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_20_var, uint8_t* global_workspace_21_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    T_add[ax1_inner] = (p0[ax1_inner] + (int64_t)4);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_3(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_28_var, uint8_t* global_workspace_29_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_add[ax0_inner] = (p0[ax0_inner] + (int64_t)310);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_4(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_38_var, uint8_t* global_workspace_39_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_add[ax0_inner] = (p0[ax0_inner] + (int64_t)310);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_5(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_46_var, uint8_t* global_workspace_47_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_add[ax0_inner] = (p0[ax0_inner] + (int64_t)310);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_6(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_56_var, uint8_t* global_workspace_57_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_add[ax0_inner] = (p0[ax0_inner] + (int64_t)310);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_7(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_66_var, uint8_t* global_workspace_67_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_add[ax0_inner] = (p0[ax0_inner] + (int64_t)310);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_8(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_74_var, uint8_t* global_workspace_75_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_add[ax0_inner] = (p0[ax0_inner] + (int64_t)310);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_9(int64_t* p0, int64_t* T_add, uint8_t* global_const_workspace_82_var, uint8_t* global_workspace_83_var) {
  void* fused_constant_12_let = (&(global_const_workspace_82_var[18864]));
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    T_add[ax1_inner] = (p0[ax1_inner] + ((int64_t*)fused_constant_12_let)[ax1_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_argmax(float* p0, int32_t* p0_red, uint8_t* global_const_workspace_94_var, uint8_t* global_workspace_95_var) {
  void* p0_red_temp_v0_let = (&(global_workspace_95_var[0]));
  void* p0_red_temp_v1_let = (&(global_workspace_95_var[16]));
  ((int32_t*)p0_red_temp_v0_let)[0] = -1;
  ((float*)p0_red_temp_v1_let)[0] = -3.402823e+38f;
  for (int32_t k1 = 0; k1 < 3; ++k1) {
    int32_t condval;
    if (((p0[k1] < ((float*)p0_red_temp_v1_let)[0]) || ((((float*)p0_red_temp_v1_let)[0] == p0[k1]) && (((int32_t*)p0_red_temp_v0_let)[0] < k1)))) {
      condval = ((int32_t*)p0_red_temp_v0_let)[0];
    } else {
      condval = k1;
    }
    ((int32_t*)p0_red_temp_v0_let)[0] = condval;
    float condval_1;
    if ((p0[k1] < ((float*)p0_red_temp_v1_let)[0])) {
      condval_1 = ((float*)p0_red_temp_v1_let)[0];
    } else {
      condval_1 = p0[k1];
    }
    ((float*)p0_red_temp_v1_let)[0] = condval_1;
  }
  p0_red[0] = ((int32_t*)p0_red_temp_v0_let)[0];
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast(int32_t* p0, int64_t* T_cast, uint8_t* global_const_workspace_96_var, uint8_t* global_workspace_97_var) {
  T_cast[0] = ((int64_t)p0[0]);
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_gather(float* p0, float* T_gather, uint8_t* global_const_workspace_2_var, uint8_t* global_workspace_3_var) {
  void* fused_constant_let = (&(global_const_workspace_2_var[18944]));
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    T_gather[ax1_inner] = p0[((int64_t*)fused_constant_let)[ax1_inner]];
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_gather_1(float* p0, int64_t* p1, float* T_gather, uint8_t* global_const_workspace_24_var, uint8_t* global_workspace_25_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    T_gather[ax1_inner] = p0[p1[ax1_inner]];
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_10_var, uint8_t* global_workspace_11_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_less[ax0_inner] = ((int8_t)(p0[ax0_inner] < (int64_t)0));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_1(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_18_var, uint8_t* global_workspace_19_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    T_less[ax1_inner] = ((int8_t)(p0[ax1_inner] < (int64_t)0));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_2(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_26_var, uint8_t* global_workspace_27_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_less[ax0_inner] = ((int8_t)(p0[ax0_inner] < (int64_t)0));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_3(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_36_var, uint8_t* global_workspace_37_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_less[ax0_inner] = ((int8_t)(p0[ax0_inner] < (int64_t)0));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_4(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_44_var, uint8_t* global_workspace_45_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_less[ax0_inner] = ((int8_t)(p0[ax0_inner] < (int64_t)0));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_5(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_54_var, uint8_t* global_workspace_55_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_less[ax0_inner] = ((int8_t)(p0[ax0_inner] < (int64_t)0));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_6(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_64_var, uint8_t* global_workspace_65_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_less[ax0_inner] = ((int8_t)(p0[ax0_inner] < (int64_t)0));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_7(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_72_var, uint8_t* global_workspace_73_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_less[ax0_inner] = ((int8_t)(p0[ax0_inner] < (int64_t)0));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_8(int64_t* p0, int8_t* T_less, uint8_t* global_const_workspace_84_var, uint8_t* global_workspace_85_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    T_less[ax0_inner] = ((int8_t)(p0[ax0_inner] < (int64_t)0));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_equal(float* p0, int8_t* T_less_equal, uint8_t* global_const_workspace_4_var, uint8_t* global_workspace_5_var) {
  void* fused_constant_1_let = (&(global_const_workspace_4_var[19024]));
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    T_less_equal[ax1_inner] = ((int8_t)(p0[ax1_inner] <= ((float*)fused_constant_1_let)[ax1_inner]));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_equal_1(float* p0, float* p1, int8_t* T_less_equal, uint8_t* global_const_workspace_34_var, uint8_t* global_workspace_35_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    T_less_equal[ax1_inner] = ((int8_t)(p0[ax1_inner] <= p1[ax1_inner]));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_less_equal_2(float* p0, float* p1, int8_t* T_less_equal, uint8_t* global_const_workspace_62_var, uint8_t* global_workspace_63_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    T_less_equal[ax1_inner] = ((int8_t)(p0[ax1_inner] <= p1[ax1_inner]));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_sum(float* p0, float* p0_red, uint8_t* global_const_workspace_92_var, uint8_t* global_workspace_93_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 3; ++ax0_ax1_fused) {
    p0_red[ax0_ax1_fused] = 0.000000e+00f;
    for (int32_t k1 = 0; k1 < 10; ++k1) {
      p0_red[ax0_ax1_fused] = (p0_red[ax0_ax1_fused] + p0[((k1 * 3) + ax0_ax1_fused)]);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take(int64_t* p0, int64_t* T_take, uint8_t* global_const_workspace_16_var, uint8_t* global_workspace_17_var) {
  void* fused_constant_5_let = (&(global_const_workspace_16_var[8688]));
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t v_ = (int64_t)0;
    int64_t v__1 = p0[ax0_inner];
    int64_t v__2 = (v_) > (v__1) ? (v_) : (v__1);
    int64_t v__3 = (int64_t)309;
    T_take[ax0_inner] = ((int64_t*)fused_constant_5_let)[((v__2) < (v__3) ? (v__2) : (v__3))];
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_1(int64_t* p0, float* T_take, uint8_t* global_const_workspace_32_var, uint8_t* global_workspace_33_var) {
  void* fused_constant_6_let = (&(global_const_workspace_32_var[17376]));
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t v_ = (int64_t)0;
    int64_t v__1 = p0[ax0_inner];
    int64_t v__2 = (v_) > (v__1) ? (v_) : (v__1);
    int64_t v__3 = (int64_t)309;
    T_take[ax0_inner] = ((float*)fused_constant_6_let)[((v__2) < (v__3) ? (v__2) : (v__3))];
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_2(int64_t* p0, int64_t* T_take, uint8_t* global_const_workspace_42_var, uint8_t* global_workspace_43_var) {
  void* fused_constant_7_let = (&(global_const_workspace_42_var[6208]));
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t v_ = (int64_t)0;
    int64_t v__1 = p0[ax0_inner];
    int64_t v__2 = (v_) > (v__1) ? (v_) : (v__1);
    int64_t v__3 = (int64_t)309;
    T_take[ax0_inner] = ((int64_t*)fused_constant_7_let)[((v__2) < (v__3) ? (v__2) : (v__3))];
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_3(int64_t* p0, int64_t* T_take, uint8_t* global_const_workspace_50_var, uint8_t* global_workspace_51_var) {
  void* fused_constant_8_let = (&(global_const_workspace_50_var[3728]));
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t v_ = (int64_t)0;
    int64_t v__1 = p0[ax0_inner];
    int64_t v__2 = (v_) > (v__1) ? (v_) : (v__1);
    int64_t v__3 = (int64_t)309;
    T_take[ax0_inner] = ((int64_t*)fused_constant_8_let)[((v__2) < (v__3) ? (v__2) : (v__3))];
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_4(int64_t* p0, float* T_take, uint8_t* global_const_workspace_60_var, uint8_t* global_workspace_61_var) {
  void* fused_constant_9_let = (&(global_const_workspace_60_var[16128]));
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t v_ = (int64_t)0;
    int64_t v__1 = p0[ax0_inner];
    int64_t v__2 = (v_) > (v__1) ? (v_) : (v__1);
    int64_t v__3 = (int64_t)309;
    T_take[ax0_inner] = ((float*)fused_constant_9_let)[((v__2) < (v__3) ? (v__2) : (v__3))];
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_5(int64_t* p0, int64_t* T_take, uint8_t* global_const_workspace_70_var, uint8_t* global_workspace_71_var) {
  void* fused_constant_10_let = (&(global_const_workspace_70_var[13648]));
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t v_ = (int64_t)0;
    int64_t v__1 = p0[ax0_inner];
    int64_t v__2 = (v_) > (v__1) ? (v_) : (v__1);
    int64_t v__3 = (int64_t)309;
    T_take[ax0_inner] = ((int64_t*)fused_constant_10_let)[((v__2) < (v__3) ? (v__2) : (v__3))];
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_6(int64_t* p0, int64_t* T_take, uint8_t* global_const_workspace_78_var, uint8_t* global_workspace_79_var) {
  void* fused_constant_11_let = (&(global_const_workspace_78_var[11168]));
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t v_ = (int64_t)0;
    int64_t v__1 = p0[ax0_inner];
    int64_t v__2 = (v_) > (v__1) ? (v_) : (v__1);
    int64_t v__3 = (int64_t)309;
    T_take[ax0_inner] = ((int64_t*)fused_constant_11_let)[((v__2) < (v__3) ? (v__2) : (v__3))];
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_take_7(int64_t* p0, float* T_take, uint8_t* global_const_workspace_90_var, uint8_t* global_workspace_91_var) {
  void* fused_constant_13_let = (&(global_const_workspace_90_var[0]));
  for (int32_t ax0 = 0; ax0 < 10; ++ax0) {
    for (int32_t ax1_inner = 0; ax1_inner < 3; ++ax1_inner) {
      int64_t v_ = (int64_t)0;
      int64_t v__1 = p0[ax0];
      int64_t v__2 = (v_) > (v__1) ? (v_) : (v__1);
      int64_t v__3 = (int64_t)309;
      T_take[((ax0 * 3) + ax1_inner)] = ((float*)fused_constant_13_let)[((((v__2) < (v__3) ? (v__2) : (v__3)) * (int64_t)3) + ((int64_t)ax1_inner))];
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where(int8_t* p0, int64_t* T_where, uint8_t* global_const_workspace_6_var, uint8_t* global_workspace_7_var) {
  void* fused_constant_3_let = (&(global_const_workspace_6_var[18704]));
  void* fused_constant_2_let = (&(global_const_workspace_6_var[18784]));
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    int64_t condval;
    if ((0 < ((int32_t)((bool)p0[ax1_inner])))) {
      condval = ((int64_t*)fused_constant_2_let)[ax1_inner];
    } else {
      condval = ((int64_t*)fused_constant_3_let)[ax1_inner];
    }
    T_where[ax1_inner] = condval;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_1(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_14_var, uint8_t* global_workspace_15_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t condval;
    if ((0 < ((int32_t)((bool)p0[ax0_inner])))) {
      condval = p1[ax0_inner];
    } else {
      condval = p2[ax0_inner];
    }
    T_where[ax0_inner] = condval;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_10(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_80_var, uint8_t* global_workspace_81_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    int64_t condval;
    if ((0 < ((int32_t)((bool)p0[ax1_inner])))) {
      condval = p1[ax1_inner];
    } else {
      condval = p2[ax1_inner];
    }
    T_where[ax1_inner] = condval;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_11(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_88_var, uint8_t* global_workspace_89_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t condval;
    if ((0 < ((int32_t)((bool)p0[ax0_inner])))) {
      condval = p1[ax0_inner];
    } else {
      condval = p2[ax0_inner];
    }
    T_where[ax0_inner] = condval;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_2(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_22_var, uint8_t* global_workspace_23_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    int64_t condval;
    if ((0 < ((int32_t)((bool)p0[ax1_inner])))) {
      condval = p1[ax1_inner];
    } else {
      condval = p2[ax1_inner];
    }
    T_where[ax1_inner] = condval;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_3(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_30_var, uint8_t* global_workspace_31_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t condval;
    if ((0 < ((int32_t)((bool)p0[ax0_inner])))) {
      condval = p1[ax0_inner];
    } else {
      condval = p2[ax0_inner];
    }
    T_where[ax0_inner] = condval;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_4(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_40_var, uint8_t* global_workspace_41_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t condval;
    if ((0 < ((int32_t)((bool)p0[ax0_inner])))) {
      condval = p1[ax0_inner];
    } else {
      condval = p2[ax0_inner];
    }
    T_where[ax0_inner] = condval;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_5(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_48_var, uint8_t* global_workspace_49_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t condval;
    if ((0 < ((int32_t)((bool)p0[ax0_inner])))) {
      condval = p1[ax0_inner];
    } else {
      condval = p2[ax0_inner];
    }
    T_where[ax0_inner] = condval;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_6(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_52_var, uint8_t* global_workspace_53_var) {
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    int64_t condval;
    if ((0 < ((int32_t)((bool)p0[ax1_inner])))) {
      condval = p1[ax1_inner];
    } else {
      condval = p2[ax1_inner];
    }
    T_where[ax1_inner] = condval;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_7(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_58_var, uint8_t* global_workspace_59_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t condval;
    if ((0 < ((int32_t)((bool)p0[ax0_inner])))) {
      condval = p1[ax0_inner];
    } else {
      condval = p2[ax0_inner];
    }
    T_where[ax0_inner] = condval;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_8(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_68_var, uint8_t* global_workspace_69_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t condval;
    if ((0 < ((int32_t)((bool)p0[ax0_inner])))) {
      condval = p1[ax0_inner];
    } else {
      condval = p2[ax0_inner];
    }
    T_where[ax0_inner] = condval;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_where_9(int8_t* p0, int64_t* p1, int64_t* p2, int64_t* T_where, uint8_t* global_const_workspace_76_var, uint8_t* global_workspace_77_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 10; ++ax0_inner) {
    int64_t condval;
    if ((0 < ((int32_t)((bool)p0[ax0_inner])))) {
      condval = p1[ax0_inner];
    } else {
      condval = p2[ax0_inner];
    }
    T_where[ax0_inner] = condval;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(float* float_input_buffer_var, int64_t* output_buffer_var, float* output2_buffer_var, uint8_t* global_const_workspace_0_var, uint8_t* global_workspace_1_var) {
  void* sid_112_let = (&(global_workspace_1_var[160]));
  void* sid_104_let = (&(global_workspace_1_var[240]));
  void* sid_101_let = (&(global_workspace_1_var[320]));
  void* sid_94_let = (&(global_workspace_1_var[240]));
  void* sid_93_let = (&(global_workspace_1_var[160]));
  void* sid_92_let = (&(global_workspace_1_var[240]));
  void* sid_102_let = (&(global_workspace_1_var[240]));
  void* sid_89_let = (&(global_workspace_1_var[160]));
  void* sid_96_let = (&(global_workspace_1_var[0]));
  void* sid_88_let = (&(global_workspace_1_var[240]));
  void* sid_113_let = (&(global_workspace_1_var[80]));
  void* sid_86_let = (&(global_workspace_1_var[336]));
  void* sid_82_let = (&(global_workspace_1_var[288]));
  void* sid_81_let = (&(global_workspace_1_var[240]));
  void* sid_79_let = (&(global_workspace_1_var[240]));
  void* sid_66_let = (&(global_workspace_1_var[160]));
  void* sid_74_let = (&(global_workspace_1_var[400]));
  void* sid_100_let = (&(global_workspace_1_var[160]));
  void* sid_61_let = (&(global_workspace_1_var[80]));
  void* sid_95_let = (&(global_workspace_1_var[160]));
  void* sid_83_let = (&(global_workspace_1_var[160]));
  void* sid_60_let = (&(global_workspace_1_var[160]));
  void* sid_59_let = (&(global_workspace_1_var[288]));
  void* sid_110_let = (&(global_workspace_1_var[352]));
  void* sid_78_let = (&(global_workspace_1_var[320]));
  void* sid_67_let = (&(global_workspace_1_var[80]));
  void* sid_29_let = (&(global_workspace_1_var[320]));
  void* sid_27_let = (&(global_workspace_1_var[0]));
  void* sid_109_let = (&(global_workspace_1_var[336]));
  void* sid_108_let = (&(global_workspace_1_var[288]));
  void* sid_80_let = (&(global_workspace_1_var[80]));
  void* sid_98_let = (&(global_workspace_1_var[320]));
  void* sid_16_let = (&(global_workspace_1_var[288]));
  void* sid_135_let = (&(global_workspace_1_var[160]));
  void* sid_103_let = (&(global_workspace_1_var[80]));
  void* sid_63_let = (&(global_workspace_1_var[336]));
  void* sid_3_let = (&(global_workspace_1_var[80]));
  void* sid_58_let = (&(global_workspace_1_var[240]));
  void* sid_90_let = (&(global_workspace_1_var[80]));
  void* sid_70_let = (&(global_workspace_1_var[160]));
  void* sid_23_let = (&(global_workspace_1_var[240]));
  void* sid_111_let = (&(global_workspace_1_var[240]));
  void* sid_62_let = (&(global_workspace_1_var[288]));
  void* sid_5_let = (&(global_workspace_1_var[320]));
  void* sid_14_let = (&(global_workspace_1_var[160]));
  void* sid_85_let = (&(global_workspace_1_var[288]));
  void* sid_28_let = (&(global_workspace_1_var[400]));
  void* sid_15_let = (&(global_workspace_1_var[80]));
  void* sid_91_let = (&(global_workspace_1_var[352]));
  void* sid_17_let = (&(global_workspace_1_var[336]));
  void* sid_87_let = (&(global_workspace_1_var[352]));
  void* sid_30_let = (&(global_workspace_1_var[240]));
  void* sid_99_let = (&(global_workspace_1_var[240]));
  void* sid_65_let = (&(global_workspace_1_var[240]));
  void* sid_21_let = (&(global_workspace_1_var[80]));
  void* sid_4_let = (&(global_workspace_1_var[0]));
  void* sid_156_let = (&(global_workspace_1_var[464]));
  void* sid_22_let = (&(global_workspace_1_var[352]));
  void* sid_24_let = (&(global_workspace_1_var[160]));
  void* sid_33_let = (&(global_workspace_1_var[240]));
  void* sid_48_let = (&(global_workspace_1_var[240]));
  void* sid_25_let = (&(global_workspace_1_var[240]));
  void* sid_9_let = (&(global_workspace_1_var[320]));
  void* sid_1_let = (&(global_workspace_1_var[0]));
  void* sid_69_let = (&(global_workspace_1_var[240]));
  void* sid_77_let = (&(global_workspace_1_var[160]));
  void* sid_36_let = (&(global_workspace_1_var[288]));
  void* sid_114_let = (&(global_workspace_1_var[352]));
  void* sid_6_let = (&(global_workspace_1_var[240]));
  void* sid_42_let = (&(global_workspace_1_var[240]));
  void* sid_40_let = (&(global_workspace_1_var[336]));
  void* sid_68_let = (&(global_workspace_1_var[352]));
  void* sid_8_let = (&(global_workspace_1_var[80]));
  void* sid_10_let = (&(global_workspace_1_var[240]));
  void* sid_11_let = (&(global_workspace_1_var[160]));
  void* sid_84_let = (&(global_workspace_1_var[80]));
  void* sid_12_let = (&(global_workspace_1_var[240]));
  void* sid_144_let = (&(global_workspace_1_var[320]));
  void* sid_13_let = (&(global_workspace_1_var[288]));
  void* sid_71_let = (&(global_workspace_1_var[240]));
  void* sid_55_let = (&(global_workspace_1_var[320]));
  void* sid_26_let = (&(global_workspace_1_var[160]));
  void* sid_31_let = (&(global_workspace_1_var[160]));
  void* sid_32_let = (&(global_workspace_1_var[320]));
  void* sid_43_let = (&(global_workspace_1_var[160]));
  void* sid_7_let = (&(global_workspace_1_var[160]));
  void* sid_116_let = (&(global_workspace_1_var[160]));
  void* sid_37_let = (&(global_workspace_1_var[160]));
  void* sid_64_let = (&(global_workspace_1_var[352]));
  void* sid_105_let = (&(global_workspace_1_var[288]));
  void* sid_38_let = (&(global_workspace_1_var[80]));
  void* sid_18_let = (&(global_workspace_1_var[352]));
  void* sid_54_let = (&(global_workspace_1_var[160]));
  void* sid_39_let = (&(global_workspace_1_var[288]));
  void* sid_97_let = (&(global_workspace_1_var[400]));
  void* sid_76_let = (&(global_workspace_1_var[240]));
  void* sid_56_let = (&(global_workspace_1_var[240]));
  void* sid_115_let = (&(global_workspace_1_var[240]));
  void* sid_41_let = (&(global_workspace_1_var[352]));
  void* sid_19_let = (&(global_workspace_1_var[240]));
  void* sid_75_let = (&(global_workspace_1_var[320]));
  void* sid_73_let = (&(global_workspace_1_var[0]));
  void* sid_44_let = (&(global_workspace_1_var[80]));
  void* sid_72_let = (&(global_workspace_1_var[160]));
  void* sid_45_let = (&(global_workspace_1_var[352]));
  void* sid_106_let = (&(global_workspace_1_var[160]));
  void* sid_20_let = (&(global_workspace_1_var[160]));
  void* sid_2_let = (&(global_workspace_1_var[160]));
  void* sid_46_let = (&(global_workspace_1_var[240]));
  void* sid_107_let = (&(global_workspace_1_var[80]));
  void* sid_35_let = (&(global_workspace_1_var[240]));
  void* sid_47_let = (&(global_workspace_1_var[160]));
  void* sid_49_let = (&(global_workspace_1_var[160]));
  void* sid_51_let = (&(global_workspace_1_var[400]));
  void* sid_50_let = (&(global_workspace_1_var[0]));
  void* sid_52_let = (&(global_workspace_1_var[320]));
  void* sid_53_let = (&(global_workspace_1_var[240]));
  void* sid_34_let = (&(global_workspace_1_var[80]));
  void* sid_57_let = (&(global_workspace_1_var[80]));
  void* sid_117_let = (&(global_workspace_1_var[240]));
  void* sid_118_let = (&(global_workspace_1_var[160]));
  void* sid_119_let = (&(global_workspace_1_var[0]));
  void* sid_120_let = (&(global_workspace_1_var[400]));
  void* sid_121_let = (&(global_workspace_1_var[320]));
  void* sid_122_let = (&(global_workspace_1_var[240]));
  void* sid_123_let = (&(global_workspace_1_var[160]));
  void* sid_124_let = (&(global_workspace_1_var[320]));
  void* sid_125_let = (&(global_workspace_1_var[240]));
  void* sid_126_let = (&(global_workspace_1_var[80]));
  void* sid_127_let = (&(global_workspace_1_var[240]));
  void* sid_128_let = (&(global_workspace_1_var[288]));
  void* sid_129_let = (&(global_workspace_1_var[160]));
  void* sid_130_let = (&(global_workspace_1_var[80]));
  void* sid_131_let = (&(global_workspace_1_var[288]));
  void* sid_132_let = (&(global_workspace_1_var[336]));
  void* sid_133_let = (&(global_workspace_1_var[352]));
  void* sid_134_let = (&(global_workspace_1_var[240]));
  void* sid_136_let = (&(global_workspace_1_var[80]));
  void* sid_137_let = (&(global_workspace_1_var[352]));
  void* sid_138_let = (&(global_workspace_1_var[240]));
  void* sid_139_let = (&(global_workspace_1_var[160]));
  void* sid_140_let = (&(global_workspace_1_var[240]));
  void* sid_141_let = (&(global_workspace_1_var[160]));
  void* sid_142_let = (&(global_workspace_1_var[0]));
  void* sid_143_let = (&(global_workspace_1_var[400]));
  void* sid_145_let = (&(global_workspace_1_var[240]));
  void* sid_146_let = (&(global_workspace_1_var[160]));
  void* sid_147_let = (&(global_workspace_1_var[320]));
  void* sid_148_let = (&(global_workspace_1_var[240]));
  void* sid_149_let = (&(global_workspace_1_var[80]));
  void* sid_150_let = (&(global_workspace_1_var[240]));
  void* sid_151_let = (&(global_workspace_1_var[288]));
  void* sid_152_let = (&(global_workspace_1_var[160]));
  void* sid_153_let = (&(global_workspace_1_var[80]));
  void* sid_154_let = (&(global_workspace_1_var[288]));
  void* sid_155_let = (&(global_workspace_1_var[448]));
  void* sid_157_let = (&(global_workspace_1_var[240]));
  void* sid_158_let = (&(global_workspace_1_var[160]));
  void* sid_159_let = (&(global_workspace_1_var[80]));
  void* sid_171_let = (&(global_workspace_1_var[16]));
  void* sid_160_let = (&(global_workspace_1_var[464]));
  void* sid_161_let = (&(global_workspace_1_var[240]));
  void* sid_162_let = (&(global_workspace_1_var[160]));
  void* sid_163_let = (&(global_workspace_1_var[368]));
  void* sid_164_let = (&(global_workspace_1_var[288]));
  void* sid_165_let = (&(global_workspace_1_var[208]));
  void* sid_166_let = (&(global_workspace_1_var[368]));
  void* sid_167_let = (&(global_workspace_1_var[288]));
  void* sid_168_let = (&(global_workspace_1_var[128]));
  void* sid_169_let = (&(global_workspace_1_var[0]));
  if (tvmgen_default_fused_gather(float_input_buffer_var, sid_1_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_equal(sid_1_let, sid_2_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where(sid_2_let, sid_3_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add(sid_3_let, sid_4_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less(sid_4_let, sid_5_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_1(sid_4_let, sid_6_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_1(sid_5_let, sid_6_let, sid_4_let, sid_7_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take(sid_7_let, sid_8_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_1(sid_8_let, sid_9_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_2(sid_8_let, sid_10_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_2(sid_9_let, sid_10_let, sid_8_let, sid_11_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_gather_1(float_input_buffer_var, sid_11_let, sid_12_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_2(sid_4_let, sid_13_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_3(sid_4_let, sid_14_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_3(sid_13_let, sid_14_let, sid_4_let, sid_15_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_1(sid_15_let, sid_16_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_equal_1(sid_12_let, sid_16_let, sid_17_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_3(sid_4_let, sid_18_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_4(sid_4_let, sid_19_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_4(sid_18_let, sid_19_let, sid_4_let, sid_20_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_2(sid_20_let, sid_21_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_4(sid_4_let, sid_22_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_5(sid_4_let, sid_23_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_5(sid_22_let, sid_23_let, sid_4_let, sid_24_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_3(sid_24_let, sid_25_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_6(sid_17_let, sid_21_let, sid_25_let, sid_26_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add(sid_26_let, sid_27_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less(sid_27_let, sid_28_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_1(sid_27_let, sid_29_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_1(sid_28_let, sid_29_let, sid_27_let, sid_30_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take(sid_30_let, sid_31_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_1(sid_31_let, sid_32_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_2(sid_31_let, sid_33_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_2(sid_32_let, sid_33_let, sid_31_let, sid_34_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_gather_1(float_input_buffer_var, sid_34_let, sid_35_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_2(sid_27_let, sid_36_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_3(sid_27_let, sid_37_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_3(sid_36_let, sid_37_let, sid_27_let, sid_38_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_1(sid_38_let, sid_39_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_equal_1(sid_35_let, sid_39_let, sid_40_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_3(sid_27_let, sid_41_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_4(sid_27_let, sid_42_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_4(sid_41_let, sid_42_let, sid_27_let, sid_43_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_2(sid_43_let, sid_44_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_4(sid_27_let, sid_45_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_5(sid_27_let, sid_46_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_5(sid_45_let, sid_46_let, sid_27_let, sid_47_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_3(sid_47_let, sid_48_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_6(sid_40_let, sid_44_let, sid_48_let, sid_49_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add(sid_49_let, sid_50_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less(sid_50_let, sid_51_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_1(sid_50_let, sid_52_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_1(sid_51_let, sid_52_let, sid_50_let, sid_53_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take(sid_53_let, sid_54_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_1(sid_54_let, sid_55_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_2(sid_54_let, sid_56_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_2(sid_55_let, sid_56_let, sid_54_let, sid_57_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_gather_1(float_input_buffer_var, sid_57_let, sid_58_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_2(sid_50_let, sid_59_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_3(sid_50_let, sid_60_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_3(sid_59_let, sid_60_let, sid_50_let, sid_61_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_1(sid_61_let, sid_62_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_equal_1(sid_58_let, sid_62_let, sid_63_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_3(sid_50_let, sid_64_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_4(sid_50_let, sid_65_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_4(sid_64_let, sid_65_let, sid_50_let, sid_66_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_2(sid_66_let, sid_67_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_4(sid_50_let, sid_68_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_5(sid_50_let, sid_69_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_5(sid_68_let, sid_69_let, sid_50_let, sid_70_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_3(sid_70_let, sid_71_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_6(sid_63_let, sid_67_let, sid_71_let, sid_72_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add(sid_72_let, sid_73_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less(sid_73_let, sid_74_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_1(sid_73_let, sid_75_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_1(sid_74_let, sid_75_let, sid_73_let, sid_76_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take(sid_76_let, sid_77_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_1(sid_77_let, sid_78_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_2(sid_77_let, sid_79_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_2(sid_78_let, sid_79_let, sid_77_let, sid_80_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_gather_1(float_input_buffer_var, sid_80_let, sid_81_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_2(sid_73_let, sid_82_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_3(sid_73_let, sid_83_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_3(sid_82_let, sid_83_let, sid_73_let, sid_84_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_1(sid_84_let, sid_85_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_equal_1(sid_81_let, sid_85_let, sid_86_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_3(sid_73_let, sid_87_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_4(sid_73_let, sid_88_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_4(sid_87_let, sid_88_let, sid_73_let, sid_89_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_2(sid_89_let, sid_90_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_4(sid_73_let, sid_91_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_5(sid_73_let, sid_92_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_5(sid_91_let, sid_92_let, sid_73_let, sid_93_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_3(sid_93_let, sid_94_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_6(sid_86_let, sid_90_let, sid_94_let, sid_95_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add(sid_95_let, sid_96_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less(sid_96_let, sid_97_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_1(sid_96_let, sid_98_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_1(sid_97_let, sid_98_let, sid_96_let, sid_99_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take(sid_99_let, sid_100_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_1(sid_100_let, sid_101_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_2(sid_100_let, sid_102_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_2(sid_101_let, sid_102_let, sid_100_let, sid_103_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_gather_1(float_input_buffer_var, sid_103_let, sid_104_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_2(sid_96_let, sid_105_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_3(sid_96_let, sid_106_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_3(sid_105_let, sid_106_let, sid_96_let, sid_107_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_1(sid_107_let, sid_108_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_equal_1(sid_104_let, sid_108_let, sid_109_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_3(sid_96_let, sid_110_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_4(sid_96_let, sid_111_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_4(sid_110_let, sid_111_let, sid_96_let, sid_112_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_2(sid_112_let, sid_113_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_4(sid_96_let, sid_114_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_5(sid_96_let, sid_115_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_5(sid_114_let, sid_115_let, sid_96_let, sid_116_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_3(sid_116_let, sid_117_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_6(sid_109_let, sid_113_let, sid_117_let, sid_118_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add(sid_118_let, sid_119_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less(sid_119_let, sid_120_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_1(sid_119_let, sid_121_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_1(sid_120_let, sid_121_let, sid_119_let, sid_122_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take(sid_122_let, sid_123_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_1(sid_123_let, sid_124_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_2(sid_123_let, sid_125_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_2(sid_124_let, sid_125_let, sid_123_let, sid_126_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_gather_1(float_input_buffer_var, sid_126_let, sid_127_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_2(sid_119_let, sid_128_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_3(sid_119_let, sid_129_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_3(sid_128_let, sid_129_let, sid_119_let, sid_130_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_1(sid_130_let, sid_131_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_equal_1(sid_127_let, sid_131_let, sid_132_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_3(sid_119_let, sid_133_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_4(sid_119_let, sid_134_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_4(sid_133_let, sid_134_let, sid_119_let, sid_135_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_2(sid_135_let, sid_136_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_4(sid_119_let, sid_137_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_5(sid_119_let, sid_138_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_5(sid_137_let, sid_138_let, sid_119_let, sid_139_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_3(sid_139_let, sid_140_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_6(sid_132_let, sid_136_let, sid_140_let, sid_141_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add(sid_141_let, sid_142_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less(sid_142_let, sid_143_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_1(sid_142_let, sid_144_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_1(sid_143_let, sid_144_let, sid_142_let, sid_145_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take(sid_145_let, sid_146_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_1(sid_146_let, sid_147_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_2(sid_146_let, sid_148_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_2(sid_147_let, sid_148_let, sid_146_let, sid_149_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_gather_1(float_input_buffer_var, sid_149_let, sid_150_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_5(sid_142_let, sid_151_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_6(sid_142_let, sid_152_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_7(sid_151_let, sid_152_let, sid_142_let, sid_153_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_4(sid_153_let, sid_154_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_equal_2(sid_150_let, sid_154_let, sid_155_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_6(sid_142_let, sid_156_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_7(sid_142_let, sid_157_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_8(sid_156_let, sid_157_let, sid_142_let, sid_158_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_5(sid_158_let, sid_159_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_7(sid_142_let, sid_160_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_8(sid_142_let, sid_161_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_9(sid_160_let, sid_161_let, sid_142_let, sid_162_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_6(sid_162_let, sid_163_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_10(sid_155_let, sid_159_let, sid_163_let, sid_164_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_9(sid_164_let, sid_165_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_less_8(sid_165_let, sid_166_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_add_10(sid_165_let, sid_167_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_where_11(sid_166_let, sid_167_let, sid_165_let, sid_168_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_take_7(sid_168_let, sid_169_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_sum(sid_169_let, output2_buffer_var, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_argmax(output2_buffer_var, sid_171_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_cast(sid_171_let, output_buffer_var, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  return 0;
}

